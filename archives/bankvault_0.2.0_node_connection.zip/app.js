//ne pas oublier : npm install socket.io
//ne pas oublier : npm install ent
var http = require('http');
var fs = require('fs');
var ent = require('ent'); // permet de bloquer les caractères HTML

var all_pass_found = []; // liste des codes trouvés
var numero_code = 0; // nombre de coffres ouverts par les utilisateurs
var magique = 0; // numéro à trouver en cours

// Début de partie ou un code à été trouvé : il faut un nouveau code de coffre
var new_coffre = function()
{
 if(numero_code > 0)
 {
  all_pass_found[all_pass_found.length] = magique;
 }
  numero_code++;
  magique =  Math.floor(10000*Math.random());
  console.log('Nouveau code secret : ' + magique);
  console.log('Ensemble des codes trouvés ' + all_pass_found);
}

new_coffre();

// Chargement du fichier index.html affiché au client
var server = http.createServer(function(req, res) {
    fs.readFile('./index.html', 'utf-8', function(error, content) {
        res.writeHead(200, {"Content-Type": "text/html"});
        res.end(content);
    });
});

// Chargement de socket.io
var io = require('socket.io').listen(server);

io.sockets.on('connection', function (socket) { // lié à socket, demandé par un des utilisateurs.

    // Dès qu'on nous donne un pseudo, on le stocke en variable de session
    socket.on('petit_nouveau', function(pseudo) {
        socket.pseudo = ent.encode(pseudo);
    });

    // Dès qu'on reçoit une proposition de code, on la traite pour vérifier sa validité
    socket.on('proposition_code', function (message) {
        socket.nombre = parseInt(ent.encode(message) , 10); //ent puis conversion en base 10
        if(socket.nombre > -0.5 & socket.nombre < 9999.5) {
            console.log(socket.pseudo + ' me parle ! Il me dit : ' + socket.nombre);
            if(socket.nombre == magique) {
                socket.resultat = 'yesss';
                socket.message = '<p><strong>' + socket.nombre + '</strong> ' + 
                                 socket.resultat + ' pour le code '+ numero_code + '</p>';
                socket.emit('envoi_html', {message: socket.message});
                new_coffre_player(socket);
            }
            else {
                socket.resultat = 'nop';
                socket.message = '<p><strong>' + socket.nombre + '</strong> ' + socket.resultat + '</p>';
                socket.emit('envoi_html', {message: socket.message});
            }
        }
    }); 
});

var new_coffre_player = function(socket)
{
 if(numero_code < 10000) {
  new_coffre();
  socket.broadcast.emit('coffre_id_update', numero_code);
  socket.emit('coffre_id_update', numero_code);
 } 
 else {
  console.log('Fin du jeu, trop de coffres ont été ouverts.');
  magique = -1;
 }
}

server.listen(8080);
