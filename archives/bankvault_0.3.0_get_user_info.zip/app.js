//ne pas oublier : npm install socket.io
//ne pas oublier : npm install ent
//ne pas oublier : npm install shortid
var http = require('http');
var url = require('url');
var fs = require('fs');
var ent = require('ent'); // permet de bloquer les caractères HTML
var shortid = require('shortid');
var express = require('express');

var app = express();

var pass_found = []; // liste des codes trouvés
var vault_number = 0; // nombre de coffres ouverts par les utilisateurs
var magique = 0; // numéro à trouver en cours

var num_players = 0; //number of player

// Début de partie ou un code à été trouvé : il faut un nouveau code de coffre
var new_vault = function()
{
 if(vault_number > 0)
 {
  pass_found[pass_found.length] = magique;
 }
  vault_number++;
  magique =  Math.floor(10000*Math.random());
  console.log('Nouveau code secret : ' + magique);
  console.log('Ensemble des codes trouvés ' + pass_found);
}

new_vault();


app.get('/index.html', function(req, res) {
    fs.readFile('./index.html', 'utf-8', function(error, content) {
        res.writeHead(200, {"Content-Type": "text/html"});
        res.end(content);
    });
});

app.get('/about.html', function(req, res) {
    res.setHeader('Content-Type', 'text/plain');
    res.end('Hello everybody, everybody hello, hello everybody, everybody hello.');
});

app.use(function(req, res, next){
  res.redirect('/index.html');
});



// http://stackoverflow.com/questions/17696801/express-js-app-listen-vs-server-listen
var server = app.listen(8080);

// http://lostechies.com/derickbailey/2013/12/04/getting-the-real-client-ip-address-on-a-heroku-hosted-nodejs-app/
/*
var ipAddr = req.headers["x-forwarded-for"];
if (ipAddr){
var list = ipAddr.split(",");
ipAddr = list[list.length-1];
} else {
ipAddr = req.connection.remoteAddress;
} 
console.log(ipAddr);
*/





// Chargement de socket.io

var io = require('socket.io').listen(server);
io.sockets.on('connection', function (socket) { // lié à socket, demandé par un des utilisateurs.

        num_players++
        console.log('Now ' + num_players + ' players.');



// ID : 
socket.id = shortid.generate();

// IP :
// http://stackoverflow.com/questions/26802808/node-js-socket-io-socket-request-undefined
socket.ip = socket.request.connection.remoteAddress //les versions < 1.x de socket.io utilisent socket.handshake...

// ce qui ne fonctionne pas :
// socket.handshake.headers['x-real-ip'];
// socket.handshake.address.address; 
// socket.handshake.address.port;
// socket.connection.remoteAddress;
// socket.manager.handshaken[socket.id].address;

// Localisation (ipinfo.io : you are limited to 1000 API free requests per day)

// ipinfo.io : you are limited to 1000 API free requests per day.
var request = require('request');
//var cheerio = require('cheerio');
//socket.ip = "192.110.160.11";
//socket.ip = "177.67.82.22";
//socket.ip = "127.0.0.1";
//socket.ip = "undefined";
//socket.ip = "36.75.102.33";
var url = 'http://ipinfo.io/'+ socket.ip + '/json';
request(url, function(error, response, html){
    if(!error) {
        //console.log(url);
        //console.log(html);
        // http://stackoverflow.com/questions/7988726/extracting-json-data
        var parsed = JSON.parse(html);
        socket.country = parsed.country
    }
});

// Dates
socket.dates = []

// Propositions
socket.propositions = []

// Vault number
socket.vault = []



    // Dès qu'on nous donne un pseudo, on le stocke en variable de session
    socket.on('petit_nouveau', function(pseudo) {
        if(socket.win > 0) {
          if(pseudo == null) { pseudo = 'anonymous'; }
          socket.pseudo = ent.encode(pseudo);         
          message = '<p>And the player-breaker of the vault n°' + socket.win + ' is ... : <strong>' + socket.pseudo + '</strong> ! </p>';
          socket.win = 0;
          socket.broadcast.emit('envoi_html', {message: message});

        }
        else {
           //non conforme, quelqu'un a essayé d'émettre avec petit_nouveau
        }
    });

    // Dès qu'on reçoit une proposition de code, on la traite pour vérifier sa validité
    socket.on('code_proposition', function (code_to_test) {
        socket.code_to_test = parseInt(ent.encode(code_to_test) , 10); //ent puis conversion en base 10
        if(socket.code_to_test > -0.5 & socket.code_to_test < 9999.5) {

// Dates
socket.dates.push(Date.now()/1000); //date en secondes
console.log('dates : ' + socket.dates);

// Propositions
socket.propositions.push(socket.code_to_test);
console.log('codes : ' + socket.propositions);

socket.win = 0;

// Vault number
socket.vault.push(vault_number);
console.log('vault_num : ' + socket.vault);


console.log('id_player : ' + socket.id);
console.log('ip_player : ' + socket.ip); 
console.log('country_player : ' + socket.country); 


            if(socket.code_to_test == magique) {
                socket.resultat = 'yesss';
                socket.message = '<p><strong>' + socket.code_to_test + '</strong> ' + 
                                 socket.resultat + ' pour le code '+ vault_number + '</p>';
                socket.emit('envoi_html', {message: socket.message});

                socket.win = vault_number;
                socket.emit('ask_nickname');

                new_vault_player(socket);
            }
            else {
                socket.resultat = 'nop';
                socket.message = '<p><strong>' + socket.code_to_test + '</strong> ' + socket.resultat + '</p>';
                socket.emit('envoi_html', {message: socket.message});
            }
        }
    }); 


// http://stackoverflow.com/questions/10342548/socket-io-disconnect-event-isnt-fired
    socket.on('disconnect', function () {
        num_players--
        console.log('Now ' + num_players + ' players.');

        });


});




var new_vault_player = function(socket)
{
 if(vault_number < 10000) {
  new_vault();
  socket.broadcast.emit('vault_num_update', vault_number);
  //socket.emit('vault_num_update', vault_number);
 } 
 else {
  console.log('Fin du jeu, trop de vaults ont été ouverts.');
  magique = -1;
 }
}

