// Load the app :
// npm install
// node app.js
// localhost:8080

var http = require('http'),
  url = require('url'),
  fs = require('fs'),
  ent = require('ent'), // to prevent users to use html code
  shortid = require('shortid'),
  express = require('express'),
  request = require('request');

var vault_num = 0, // number of vaults opened
  pass = 0, // current pass to find
  pass_found = []; // list of cracked passes

var num_players = 0; // number of players

// Helper functions
// function to get a new vault
var new_vault = function() {
  if(vault_num > 0) {
    pass_found[pass_found.length] = pass;
  }
  vault_num++;
  pass =  Math.floor(10000*Math.random());
  console.log('New secret pass: ' + pass);
  console.log('List of cracked passes ' + pass_found);
}

// function when a player found a pass
var new_vault_player = function(socket) {
  if(vault_num < 10000) {
    new_vault();
    socket.message = '<p> Vault ' + (vault_num-1) + ' is now open...' +
                      vault_num + ' is the new vault to enter! </p>';
    socket.broadcast.emit('send_html', {message: socket.message});
    // socket.emit('send_html', {message: socket.message});
  } 
  else {
    console.log('Fin du jeu, trop de vaults ont été ouverts.');
    pass = -1;
  }
}

// Server initialization
new_vault();

var app = express();

app.get('/index.html', function(req, res) {
  fs.readFile('./index.html', 'utf-8', function(error, content) {
    res.writeHead(200, {"Content-Type": "text/html"});
    res.end(content);
  });
});

app.get('/about.html', function(req, res) {
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello everybody, everybody hello, hello everybody, everybody hello.');
});

app.use(function(req, res, next){
  res.redirect('/index.html');
});

// http://stackoverflow.com/questions/17696801/express-js-app-listen-vs-server-listen
var server = app.listen(8080);

// http://lostechies.com/derickbailey/2013/12/04/getting-the-real-client-ip-address-on-a-heroku-hosted-nodejs-app/
/*
var ipAddr = req.headers["x-forwarded-for"];
if (ipAddr){
var list = ipAddr.split(",");
ipAddr = list[list.length-1];
} else {
ipAddr = req.connection.remoteAddress;
} 
console.log(ipAddr);
*/

// Loading and using socket.io
var io = require('socket.io').listen(server);
io.sockets.on('connection', function (socket) { // each socket is linked to a player
  num_players++
  console.log('Now ' + num_players + ' player(s).');

  // id 
  socket.id = shortid.generate();

  // ip
  // http://stackoverflow.com/questions/26802808/node-js-socket-io-socket-request-undefined
  socket.ip = socket.request.connection.remoteAddress
  // those one didn't work (versions >= 1.x of socket.io don't use socket.handshake)
  // socket.handshake.headers['x-real-ip'];
  // socket.handshake.address.address; 
  // socket.handshake.address.port;
  // socket.connection.remoteAddress;
  // socket.manager.handshaken[socket.id].address;

  // Location
  // use ipinfo.io (limited to 1000 API free requests per day).
  // socket.ip = "192.110.160.11";
  // socket.ip = "177.67.82.22";
  // socket.ip = "127.0.0.1";
  // socket.ip = "undefined";
  // socket.ip = "36.75.102.33";
  var url = 'http://ipinfo.io/'+ socket.ip + '/json';
  request(url, function(error, response, html) {
    if(!error) {
      // console.log(html);
      // http://stackoverflow.com/questions/7988726/extracting-json-data
      var parsed = JSON.parse(html);
      socket.country = parsed.country
    }
  });

  // Dates
  socket.dates = []

  // Propositions
  socket.propositions = []

  // Vault num
  socket.vault = []

  // Checking a pass proposition
  socket.on('pass_proposition', function (pass_to_test) {
    socket.pass_to_test = parseInt(ent.encode(pass_to_test), 10); //ent, then conversion to base 10
    if(socket.pass_to_test > -0.5 & socket.pass_to_test < 9999.5) {
      // Dates
      socket.dates.push(Date.now()/1000); //date in seconds

      // Propositions
      socket.propositions.push(socket.pass_to_test);

      // Vault number
      socket.vault.push(vault_num);

      console.log('dates: ' + socket.dates);
      console.log('passes: ' + socket.propositions);
      console.log('vault_num: ' + socket.vault);
      console.log('id_player: ' + socket.id);
      console.log('ip_player: ' + socket.ip); 
      console.log('country_player: ' + socket.country); 

      socket.win = 0;

      if(socket.pass_to_test == pass) {
        socket.message = '<p><strong>' + socket.pass_to_test + 
                         '</strong> is the correct password for the vault n°' +
                         vault_num + '! Congratulations.</p>';
        socket.emit('send_html', {message: socket.message});

        socket.win = vault_num;
        socket.emit('ask_nickname');
        new_vault_player(socket);
      }
      else {
        socket.message = '<p><strong>' + socket.pass_to_test + '</strong> nop </p>';
        socket.emit('send_html', {message: socket.message});
      }
    }
  }); 

  // Asking the nickname when the player wins
  socket.on('send_nickname', function(pseudo) {
    if(socket.win > 0) {
      if(pseudo == null) { 
        pseudo = 'anonymous'; 
      }
      socket.pseudo = ent.encode(pseudo);         
      socket.message = '<p>The player who broke the vault n°' + socket.win + ' is... <strong>' + socket.pseudo + '</strong>! </p>';
      socket.win = 0;
      socket.broadcast.emit('send_html', {message: socket.message});
    }
    else {
      // not in accordance with the code
    }
  });

  // Disconnection of a player
  // http://stackoverflow.com/questions/10342548/socket-io-disconnect-event-isnt-fired
  socket.on('disconnect', function () {
    num_players--
    console.log('Now ' + num_players + ' player(s).');
  });
});
